// swift-tools-version: 6.0
import PackageDescription
let package = Package(
    name: "GezelRuntime",
    platforms: [.iOS("16.4")],
    products: [
        .library(name: "GezelRuntime", targets: ["GezelRuntime"]),
        .library(name: "GezelModelStorage", targets: ["GezelModelStorage"])
    ],
    targets: [
        .binaryTarget(name: "GezelLlama", path: "GezelLlama.xcframework"),
        .target(name: "GezelModelStorage", resources: [.copy("PrivacyInfo.xcprivacy")]),
        .target(name: "GezelRuntime", dependencies: ["GezelLlama", "GezelModelStorage"],
                resources: [.copy("PrivacyInfo.xcprivacy")])
    ],
    swiftLanguageModes: [.v5]
)
